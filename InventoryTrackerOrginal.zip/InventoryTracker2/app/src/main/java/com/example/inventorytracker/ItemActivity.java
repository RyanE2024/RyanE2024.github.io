package com.example.inventorytracker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;

public class ItemActivity extends AppCompatActivity {

    EditText itemName, quantity, location;
    Button saveBtn, updateBtn, deleteBtn;
    DatabaseHelper databaseHelper;

    int itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        itemName = findViewById(R.id.itemName);
        quantity = findViewById(R.id.quantity);
        location = findViewById(R.id.location);

        saveBtn = findViewById(R.id.saveBtn);
        updateBtn = findViewById(R.id.updateBtn);
        deleteBtn = findViewById(R.id.deleteBtn);

        databaseHelper = new DatabaseHelper(this);

        // Check if editing an existing item
        if (getIntent().hasExtra("ITEM_ID")) {
            itemId = getIntent().getIntExtra("ITEM_ID", -1);

            Cursor cursor = databaseHelper.getAllItems();
            while (cursor.moveToNext()) {
                if (cursor.getInt(0) == itemId) {
                    itemName.setText(cursor.getString(1));
                    quantity.setText(String.valueOf(cursor.getInt(2)));
                    location.setText(cursor.getString(3));
                }
            }
            cursor.close();
        }

        saveBtn.setOnClickListener(v -> {
            String name = itemName.getText().toString().trim();
            int qty = Integer.parseInt(quantity.getText().toString().trim());
            String loc = location.getText().toString().trim();

            boolean inserted = databaseHelper.addItem(name, qty, loc);

            if (inserted) {
                Toast.makeText(this, "Item Saved", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        updateBtn.setOnClickListener(v -> {
            if (itemId != -1) {
                String name = itemName.getText().toString().trim();
                int qty = Integer.parseInt(quantity.getText().toString().trim());
                String loc = location.getText().toString().trim();

                boolean updated = databaseHelper.updateItem(itemId, name, qty, loc);

                if (updated) {
                    Toast.makeText(this, "Item Updated", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        deleteBtn.setOnClickListener(v -> {
            if (itemId != -1) {
                boolean deleted = databaseHelper.deleteItem(itemId);

                if (deleted) {
                    Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}