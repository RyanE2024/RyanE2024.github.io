package com.example.inventorytracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    Button addItemBtn, smsBtn;
    ListView listView;
    DatabaseHelper databaseHelper;
    ArrayList<String> itemList;
    ArrayAdapter<String> adapter;

    private static final int SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        addItemBtn = findViewById(R.id.addItemBtn);
        smsBtn = findViewById(R.id.smsBtn);
        listView = findViewById(R.id.listView);

        databaseHelper = new DatabaseHelper(this);
        itemList = new ArrayList<>();

        loadItems();

        addItemBtn.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, ItemActivity.class);
            startActivity(intent);
        });

        smsBtn.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );

            } else {
                sendSMS();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String item = itemList.get(position);

            if (item.equals("No inventory items yet.")) {
                return;
            }

            int itemId = Integer.parseInt(
                    item.split("\\|")[0].replace("ID:", "").trim()
            );

            Intent intent = new Intent(InventoryActivity.this, ItemActivity.class);
            intent.putExtra("ITEM_ID", itemId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    private void loadItems() {
        itemList.clear();

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.getCount() == 0) {
            itemList.add("No inventory items yet.");
        } else {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int quantity = cursor.getInt(2);
                String location = cursor.getString(3);

                itemList.add("ID: " + id + " | " + name + " | Qty: " + quantity + " | " + location);
            }
        }

        cursor.close();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                itemList
        );

        listView.setAdapter(adapter);
    }

    private void sendSMS() {
        try {
            SmsManager smsManager = SmsManager.getDefault();

            // Test number for rubric demonstration
            String phoneNumber = "1234567890";

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Inventory Alert: Test message from Inventory Tracker",
                    null,
                    null
            );

            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                sendSMS();
            } else {
                Toast.makeText(this, "Permission Denied - App still works without SMS", Toast.LENGTH_SHORT).show();
            }
        }
    }
}